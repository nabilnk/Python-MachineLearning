# Simple-Linear-Regression
Menggunakan salah satu algoritma Supervised Machine Learning yaitu Simple Linear Regression
