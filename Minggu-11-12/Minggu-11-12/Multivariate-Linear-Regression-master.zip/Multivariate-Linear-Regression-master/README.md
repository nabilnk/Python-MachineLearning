# Multivariate-Linear-Regression
Melakukan prediksi harga rumah dengan menggunakan Multivariate Linear Regression
